<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>@yield('title', 'SMK Kosgoro')</title>
<script src="https://cdn.tailwindcss.com"></script>
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<script>
  tailwind.config = { theme: { extend: { colors: {
    maroon: { DEFAULT: '#7A0C1E', dark: '#5C0916' },
    gold: '#F2C200',
    cream: '#FDF1F1',
  }}}}
</script>
<style>[x-cloak]{display:none !important}</style>
</head>
<body class="bg-gradient-to-b from-cream to-white min-h-screen flex items-center justify-center p-4">
@yield('content')
</body>
</html>