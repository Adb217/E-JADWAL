<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>@yield('title', 'Admin - SMK Kosgoro')</title>
<script src="https://cdn.tailwindcss.com"></script>
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<script>
  tailwind.config = { theme: { extend: { colors: {
    maroon: { DEFAULT: '#7A0C1E', dark: '#5C0916' },
    gold: '#F2C200',
    cream: '#FDF1F1',
  }}}}
</script>
<style>[x-cloak]{display:none !important}</style>
</head>
<body class="bg-gray-50 min-h-screen pb-20" x-data="{ drawer: false }">

<header class="bg-cream border-b border-gray-200 sticky top-0 z-30">
    <div class="flex items-center justify-between px-4 py-3 max-w-md mx-auto">
        <button @click="drawer = true" class="text-maroon text-xl">☰</button>
        <h1 class="text-lg font-bold text-maroon">SMK Kosgoro</h1>
        <a href="#" class="text-maroon text-xl">👤</a>
    </div>
</header>

<div x-show="drawer" x-cloak class="fixed inset-0 bg-black/40 z-40" @click="drawer = false"></div>
@include('partials.sidebar')

<main class="max-w-md mx-auto p-4">
@yield('content')
</main>

@include('partials.bottom-nav-admin')
</body>
</html>