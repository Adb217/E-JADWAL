<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>@yield('title', 'SMK Kosgoro - Monitoring')</title>
<script src="https://cdn.tailwindcss.com"></script>
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<script>
  tailwind.config = { theme: { extend: { colors: {
    maroon: { DEFAULT: '#7A0C1E', dark: '#5C0916' },
    gold: '#F2C200',
    cream: '#FDF1F1',
  }}}}
</script>
</head>
<body class="bg-gray-50 min-h-screen pb-20">

<header class="bg-cream border-b border-gray-200 sticky top-0 z-30">
    <div class="flex items-center justify-between px-4 py-3 max-w-md mx-auto">
        <div class="flex items-center gap-2">
            <img src="https://ui-avatars.com/api/?name=SK&background=7A0C1E&color=fff" class="w-8 h-8 rounded-full">
            <h1 class="text-lg font-bold text-maroon">SMK Kosgoro</h1>
        </div>
        <a href="{{ route('login') }}" class="text-maroon text-xl">👤</a>
    </div>
</header>

<main class="max-w-md mx-auto p-4">
@yield('content')
</main>

@include('partials.bottom-nav-viewer')
</body>
</html>