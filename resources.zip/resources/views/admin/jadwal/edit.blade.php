@extends('layouts.admin')
@section('title','Edit Jadwal')
@section('content')
<div class="flex items-center gap-2 mb-4">
    <a href="{{ route('admin.jadwal.index') }}" class="text-maroon">←</a>
    <h1 class="font-bold text-lg">Edit Jadwal (Bentrok)</h1>
</div>
<form method="POST" action="{{ route('admin.jadwal.update', $id) }}">
    @csrf
    @method('PUT')
    @include('admin.jadwal._form', ['conflict' => true])
</form>
@endsection