@extends('layouts.admin')
@section('title','Tambah Jadwal')
@section('content')
<div class="flex items-center gap-2 mb-4">
    <a href="{{ route('admin.jadwal.index') }}" class="text-maroon">←</a>
    <h1 class="font-bold text-lg">Tambah Jadwal Baru</h1>
</div>
<form method="POST" action="{{ route('admin.jadwal.store') }}">
    @csrf
    @include('admin.jadwal._form', ['conflict' => false])
</form>
@endsection