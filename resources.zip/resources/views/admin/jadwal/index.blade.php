@extends('layouts.admin')
@section('title','Kelola Jadwal')
@section('content')
<h1 class="text-xl font-bold">Manajemen Jadwal</h1>
<p class="text-gray-500 text-sm mb-4">Kelola jadwal pelajaran, ruangan, dan pengajar.</p>

<div class="flex gap-3 mb-4">
    <button class="flex-1 flex items-center justify-center gap-2 border border-gray-200 rounded-xl py-3 bg-white">🔽 Filter</button>
    <a href="{{ route('admin.jadwal.create') }}" class="flex-1 flex items-center justify-center gap-2 bg-maroon text-white rounded-xl py-3 font-semibold">+ Tambah Jadwal</a>
</div>

<div class="flex gap-2 mb-4">
    <span class="bg-cream px-3 py-1 rounded-full text-sm">Hari: Senin ✕</span>
    <span class="bg-cream px-3 py-1 rounded-full text-sm">Kelas: X TKJ 1 ✕</span>
</div>

<div class="space-y-4">
    @foreach([
        ['time'=>'07:00 - 08:30','subject'=>'Matematika Lanjut','teacher'=>'Drs. Budi Santoso','room'=>'R. 101','class'=>'X TKJ 1','border'=>'border-l-gold','conflict'=>false],
        ['time'=>'08:30 - 10:00','subject'=>'Pendidikan Jasmani','teacher'=>'Agus Riyanto, S.Pd','room'=>'Lapangan A','class'=>'X TKJ 1','border'=>'border-l-maroon','conflict'=>false],
        ['time'=>'10:00 - 11:30','subject'=>'Pemrograman Web','teacher'=>'Siti Aminah, M.Kom','room'=>'Lab Kom 1','class'=>'X TKJ 1','border'=>'border-l-red-500','conflict'=>true],
    ] as $j)
    <div class="bg-white rounded-2xl border-l-4 {{ $j['border'] }} {{ $j['conflict'] ? 'border border-red-400' : 'border border-gray-100' }} p-4 shadow-sm">
        <div class="flex justify-between items-start mb-2">
            @if($j['conflict'])
                <span class="bg-red-100 text-red-600 text-xs font-bold px-2 py-1 rounded-full">⚠ BENTROK</span>
            @else
                <span class="bg-cream text-gray-500 text-xs px-2 py-1 rounded-full">{{ $j['time'] }}</span>
            @endif
            <div class="flex gap-3">
                <a href="{{ route('admin.jadwal.edit', 1) }}" class="text-blue-600">✏️</a>
                <button class="text-red-600">🗑️</button>
            </div>
        </div>
        <h3 class="font-bold text-lg">{{ $j['subject'] }}</h3>
        <p class="text-gray-500 text-sm mb-2">👤 {{ $j['teacher'] }}</p>
        <hr class="mb-2">
        <p class="text-sm {{ $j['conflict'] ? 'text-red-600 font-semibold' : 'text-gray-600' }}">🚪 {{ $j['room'] }} &nbsp; 👥 {{ $j['class'] }}</p>
    </div>
    @endforeach
</div>

<a href="{{ route('admin.jadwal.create') }}" class="fixed bottom-24 right-6 w-14 h-14 bg-maroon text-white rounded-2xl flex items-center justify-center text-2xl shadow-lg">+</a>
@endsection