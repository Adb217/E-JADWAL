<div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 mb-4">
    <h2 class="font-bold text-lg border-b pb-2 mb-4">Detail Pelajaran</h2>
    <div class="space-y-4">
        <div>
            <label class="text-sm font-semibold text-maroon">Kelas</label>
            <select name="kelas" class="w-full border rounded-xl p-3 mt-1">
                <option>X TKJ 1</option>
                <option>XI RPL 2</option>
            </select>
        </div>
        <div>
            <label class="text-sm font-semibold text-maroon">Mata Pelajaran</label>
            <select name="mapel" class="w-full border rounded-xl p-3 mt-1">
                <option>Pemrograman Web</option>
                <option>Matematika Lanjut</option>
            </select>
        </div>
        <div>
            <label class="text-sm font-semibold text-maroon">Guru Pengajar</label>
            <select name="guru" class="w-full border rounded-xl p-3 mt-1">
                <option>Budi Santoso, S.Kom</option>
                <option>Siti Aminah, M.Kom</option>
            </select>
        </div>
    </div>
</div>

<div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 mb-4">
    <h2 class="font-bold text-lg border-b pb-2 mb-4">Waktu & Tempat</h2>
    <div class="space-y-4">
        <div>
            <label class="text-sm font-semibold text-maroon">Hari</label>
            <select name="hari" class="w-full border rounded-xl p-3 mt-1">
                <option>Senin</option><option>Selasa</option>
            </select>
        </div>
        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="text-sm font-semibold text-maroon">Jam Mulai</label>
                <input type="time" name="jam_mulai" value="08:00" class="w-full border rounded-xl p-3 mt-1">
            </div>
            <div>
                <label class="text-sm font-semibold text-maroon">Jam Selesai</label>
                <input type="time" name="jam_selesai" value="09:30" class="w-full border rounded-xl p-3 mt-1">
            </div>
        </div>
        <div>
            <label class="text-sm font-semibold text-maroon">Ruangan</label>
            <select name="ruangan" class="w-full border rounded-xl p-3 mt-1">
                <option>Lab Kom 1</option><option>R. 101</option>
            </select>
        </div>
    </div>
</div>

@if(!empty($conflict))
<div class="bg-red-50 border border-red-300 rounded-2xl p-4 mb-4 text-center">
    <p class="font-bold text-red-600 mb-1">⚠ Jadwal Bentrok</p>
    <p class="text-sm text-red-500">Ruangan/guru sudah terpakai pada jam yang sama.</p>
</div>
@else
<div class="bg-white rounded-2xl p-6 mb-4 text-center border border-gray-100">
    <div class="w-14 h-14 rounded-2xl bg-cream flex items-center justify-center text-2xl mx-auto mb-3">📅</div>
    <p class="text-gray-500 text-sm">Lengkapi form untuk memeriksa ketersediaan jadwal dan ruangan.</p>
</div>
@endif

<button type="submit" class="w-full bg-maroon text-white font-bold py-3 rounded-xl mb-2">💾 Simpan Jadwal</button>
<a href="{{ route('admin.jadwal.index') }}" class="block text-center text-maroon font-semibold">Batal</a>