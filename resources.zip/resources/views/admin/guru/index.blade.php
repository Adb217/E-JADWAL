@extends('layouts.admin')
@section('title','Data Guru')
@section('content')
<h1 class="text-xl font-bold">Data Guru</h1>
<p class="text-gray-500 text-sm mb-4">Kelola daftar tenaga pendidik SMK Kosgoro.</p>

<div class="relative mb-4">
    <span class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">🔍</span>
    <input type="text" placeholder="Cari Nama / NIP..." class="w-full pl-10 pr-4 py-3 rounded-xl bg-cream border border-gray-200">
</div>

<button class="w-full bg-maroon text-white font-bold py-3 rounded-xl mb-4">+ Tambah Guru</button>

<div class="space-y-4">
    @foreach([
        ['name'=>'Budi Santoso, S.Pd','nip'=>'19800512 200501 1 003','tags'=>['Matematika','Fisika'],'status'=>'Aktif','border'=>'border-l-maroon'],
        ['name'=>'Siti Aminah, M.Kom','nip'=>'19851120 201001 2 001','tags'=>['RPL','KKPI'],'status'=>'Aktif','border'=>'border-l-gold'],
        ['name'=>'Drs. Ahmad Yani','nip'=>'19750310 200003 1 005','tags'=>['Bahasa Indonesia'],'status'=>'Cuti','border'=>'border-l-gray-400'],
    ] as $g)
    <div class="bg-white rounded-2xl border-l-4 {{ $g['border'] }} border border-gray-100 p-4 shadow-sm">
        <div class="flex justify-between items-start">
            <div>
                <h3 class="font-bold">{{ $g['name'] }}</h3>
                <p class="text-gray-500 text-sm mb-2">NIP: {{ $g['nip'] }}</p>
            </div>
            <span class="bg-cream text-maroon text-xs font-semibold px-3 py-1 rounded-full h-fit">{{ $g['status'] }}</span>
        </div>
        <div class="flex gap-2 mb-3">
            @foreach($g['tags'] as $tag)
            <span class="bg-cream text-sm px-3 py-1 rounded-full">{{ $tag }}</span>
            @endforeach
        </div>
        <hr class="mb-2">
        <div class="flex justify-end gap-3">
            <button class="text-blue-600">✏️</button>
            <button class="text-red-600">🗑️</button>
        </div>
    </div>
    @endforeach
</div>
@endsection