@extends('layouts.admin')
@section('title','Data Kelas')
@section('content')
<h1 class="text-xl font-bold mb-1">Data Kelas</h1>
<p class="text-gray-500 text-sm mb-4">Kelola daftar kelas SMK Kosgoro.</p>
<button class="w-full bg-maroon text-white font-bold py-3 rounded-xl mb-4">+ Tambah Kelas</button>
<div class="bg-white rounded-2xl border border-gray-100 p-6 text-center text-gray-400">
    Belum ada desain untuk halaman ini — silakan sesuaikan.
</div>
@endsection