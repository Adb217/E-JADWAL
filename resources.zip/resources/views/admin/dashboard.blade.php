@extends('layouts.admin')
@section('title','Admin Dashboard')
@section('content')
<div class="grid grid-cols-2 gap-4 mb-6">
    <div class="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
        <div class="w-10 h-10 rounded-xl bg-maroon/10 flex items-center justify-center mb-2">🚪</div>
        <p class="text-sm text-gray-500">Total Kelas</p>
        <p class="text-2xl font-bold">12</p>
    </div>
    <div class="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
        <div class="w-10 h-10 rounded-xl bg-gold/20 flex items-center justify-center mb-2">👥</div>
        <p class="text-sm text-gray-500">Total Guru</p>
        <p class="text-2xl font-bold">24</p>
    </div>
    <div class="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
        <div class="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center mb-2">✅</div>
        <p class="text-sm text-gray-500">Ruang Terpakai</p>
        <p class="text-2xl font-bold">8</p>
    </div>
    <div class="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
        <div class="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center mb-2">❌</div>
        <p class="text-sm text-gray-500">Ruang Kosong</p>
        <p class="text-2xl font-bold">4</p>
    </div>
</div>

<div class="bg-white rounded-2xl border border-gray-100 shadow-sm mb-6">
    <div class="flex items-center justify-between p-4 border-b">
        <h2 class="font-bold text-lg">Jadwal Hari Ini</h2>
        <a href="{{ route('admin.jadwal.index') }}" class="text-maroon text-sm font-semibold">Lihat Semua</a>
    </div>
    <table class="w-full text-sm">
        <thead class="text-gray-400 text-xs">
            <tr><th class="text-left p-3">Waktu</th><th class="text-left p-3">Kelas</th><th class="text-left p-3">Mata Pelajaran</th></tr>
        </thead>
        <tbody>
            @foreach([
                ['07:15 - 08:45','X RPL 1','Pemrograman Dasar'],
                ['07:15 - 08:45','XI TKJ 2','Administrasi Server'],
                ['08:45 - 10:15','X AKL 1','Akuntansi Dasar'],
            ] as $row)
            <tr class="border-t">
                <td class="p-3 font-bold">{{ $row[0] }}</td>
                <td class="p-3">{{ $row[1] }}</td>
                <td class="p-3 font-semibold">{{ $row[2] }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>

<div class="bg-cream rounded-2xl p-4">
    <h2 class="font-bold text-lg mb-4">Perubahan Terkini</h2>
    <div class="space-y-4 border-l-2 border-maroon/30 pl-4">
        @foreach([
            ['dot'=>'bg-maroon','title'=>'Guru Berhalangan','time'=>'10 mnt lalu','desc'=>'Bpk. Anton (Matematika) izin sakit. Perlu guru pengganti untuk kelas XI MM 1.'],
            ['dot'=>'bg-gold','title'=>'Pindah Ruangan','time'=>'1 jam lalu','desc'=>'Kelas XII RPL 2 dipindah dari Lab Kom 2 ke R. Teori 5 (Perbaikan AC).'],
            ['dot'=>'bg-maroon','title'=>'Tukar Jadwal','time'=>'2 jam lalu','desc'=>'Jadwal Penjaskes (X TKJ 1) ditukar.'],
        ] as $item)
        <div class="relative bg-white rounded-xl p-3 -ml-6 pl-6 border border-gray-100">
            <span class="absolute -left-[21px] top-4 w-3 h-3 rounded-full {{ $item['dot'] }}"></span>
            <div class="flex justify-between text-sm">
                <span class="font-bold">{{ $item['title'] }}</span>
                <span class="text-gray-400 text-xs">{{ $item['time'] }}</span>
            </div>
            <p class="text-sm text-gray-600 mt-1">{{ $item['desc'] }}</p>
        </div>
        @endforeach
    </div>
</div>
@endsection