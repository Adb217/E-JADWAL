@extends('layouts.viewer')
@section('title','Detail Ruangan')
@section('content')
<a href="{{ route('viewer.ruangan.index') }}" class="text-maroon text-xl mb-4 inline-block">←</a>

<div class="bg-white rounded-2xl border border-gray-100 shadow-sm mb-6 overflow-hidden">
    <div class="p-5">
        <h2 class="text-2xl font-bold">Labkom RPL</h2>
        <p class="text-gray-500 text-sm mb-2">💻 Laboratorium Komputer</p>
        <span class="bg-maroon text-white text-xs font-semibold px-3 py-1 rounded-full">● TERPAKAI</span>
    </div>
    <div class="bg-maroon text-white p-4 flex items-center gap-3">
        <div class="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center text-xl">🎓</div>
        <div>
            <p class="text-xs uppercase tracking-wide text-white/70">Sedang Berlangsung</p>
            <p class="font-bold">Bpk. Budi Santoso, S.Kom</p>
            <p class="text-sm text-white/80">Pemrograman Web - Kelas XI RPL</p>
        </div>
    </div>
</div>

<h2 class="font-bold text-lg mb-3">Jadwal Hari Ini</h2>
<div class="relative pl-6 space-y-4 border-l-2 border-gray-200">
    @foreach([
        ['time'=>'08:00 - 09:30','subject'=>'Informatika','class'=>'XII DKV','status'=>'SELESAI','active'=>false],
        ['time'=>'09:30 - 11:00','subject'=>'Pemrograman Web','class'=>'XI RPL','status'=>null,'active'=>true],
        ['time'=>'11:00 - 12:30','subject'=>null,'class'=>'Ruangan Kosong','status'=>null,'active'=>null],
    ] as $s)
    <div class="relative -ml-[29px] pl-6">
        <span class="absolute left-0 top-4 w-3 h-3 rounded-full {{ $s['active'] ? 'bg-maroon' : ($s['active']===false ? 'bg-gray-300' : 'bg-gray-200') }}"></span>
        <div class="bg-white rounded-xl border {{ $s['active'] ? 'border-maroon' : 'border-gray-100 border-dashed' }} p-4">
            <div class="flex justify-between items-center mb-1">
                <span class="font-semibold {{ $s['active'] ? 'text-maroon' : 'text-gray-400' }}">🕐 {{ $s['time'] }}</span>
                @if($s['status'])
                <span class="bg-cream text-gray-500 text-xs px-2 py-1 rounded-full">{{ $s['status'] }}</span>
                @endif
            </div>
            @if($s['subject'])
                <p class="font-bold {{ $s['active'] ? '' : 'text-gray-400' }}">{{ $s['subject'] }}</p>
                <p class="text-sm text-gray-500">{{ $s['class'] }}</p>
            @else
                <p class="text-center text-gray-400">🚪 {{ $s['class'] }}</p>
            @endif
        </div>
    </div>
    @endforeach
</div>
@endsection