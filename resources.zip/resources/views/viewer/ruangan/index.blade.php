@extends('layouts.viewer')
@section('title','Status Ruangan')
@section('content')
<h1 class="text-xl font-bold mb-1">Status Ruangan</h1>
<p class="text-gray-500 text-sm mb-4">Pantau ketersediaan ruangan secara real-time.</p>

<div class="flex gap-2 mb-4 overflow-x-auto">
    <button class="bg-maroon text-white px-4 py-2 rounded-full text-sm whitespace-nowrap">Semua</button>
    <button class="bg-white border border-gray-200 px-4 py-2 rounded-full text-sm whitespace-nowrap">Lab Komputer</button>
    <button class="bg-white border border-gray-200 px-4 py-2 rounded-full text-sm whitespace-nowrap">Kelas Reguler</button>
</div>

<div class="space-y-4">
    @foreach($rooms as $r)
    <a href="{{ route('viewer.ruangan.show', $r['id']) }}" class="block bg-white rounded-2xl border-l-4 {{ $r['used'] ? 'border-l-maroon' : 'border-l-green-500' }} border border-gray-100 p-4 shadow-sm">
        <div class="flex justify-between items-center mb-2">
            <h3 class="font-bold uppercase">{{ $r['name'] }}</h3>
            <span class="{{ $r['used'] ? 'bg-maroon text-white' : 'bg-green-100 text-green-700' }} text-xs font-semibold px-3 py-1 rounded-full">
                {{ $r['used'] ? 'TERPAKAI' : '● KOSONG' }}
            </span>
        </div>
        @if($r['used'])
        <p class="text-sm text-gray-600">👥 {{ $r['class'] }}</p>
        <p class="text-sm text-gray-600">📖 {{ $r['subject'] }}</p>
        <p class="text-sm text-gray-600">👤 {{ $r['teacher'] }}</p>
        <p class="text-sm text-gray-600">🕐 Selesai {{ $r['end'] }} (sisa {{ $r['remaining'] }})</p>
        @else
        <div class="text-center py-4 text-gray-400">
            <p class="text-2xl mb-1">🚪</p>
            <p class="text-sm">Ruangan tersedia untuk digunakan.</p>
            <p class="text-sm">Jadwal berikutnya: {{ $r['next'] }}</p>
        </div>
        @endif
    </a>
    @endforeach
</div>
@endsection