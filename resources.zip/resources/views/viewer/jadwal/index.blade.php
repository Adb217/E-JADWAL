@extends('layouts.viewer')
@section('title','Jadwal')
@section('content')
<div class="relative mb-4">
    <span class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">🔍</span>
    <input type="text" placeholder="Search by class, subject, or teacher..." class="w-full pl-10 pr-4 py-3 rounded-xl bg-cream border border-gray-200">
</div>
<div class="flex gap-3 mb-4">
    <select class="flex-1 border border-gray-200 rounded-xl p-3 bg-white text-sm">
        <option>All Classes</option>
    </select>
    <select class="flex-1 border border-gray-200 rounded-xl p-3 bg-white text-sm">
        <option>Today</option>
    </select>
</div>

<div class="space-y-4">
    @foreach($jadwal as $j)
    <div class="bg-white rounded-2xl border-l-4 {{ $j['border'] }} border border-gray-100 p-4 shadow-sm {{ $j['status']=='Selesai' ? 'opacity-50' : '' }}">
        <div class="flex justify-between items-center mb-2">
            <span class="font-bold text-lg">{{ $j['start'] }} <span class="text-gray-400 text-sm font-normal">- {{ $j['end'] }}</span></span>
            <span class="{{ $j['badge'] }} text-xs font-semibold px-3 py-1 rounded-full">{{ $j['status'] }}</span>
        </div>
        <h3 class="font-bold">{{ $j['subject'] }}</h3>
        <p class="text-gray-500 text-sm mb-2">{{ $j['class'] }}</p>
        <p class="text-sm text-gray-600">👤 {{ $j['teacher'] }} &nbsp; 🚪 {{ $j['room'] }}</p>
    </div>
    @endforeach
</div>
@endsection