@extends('layouts.viewer')
@section('title','Monitoring Jadwal')
@section('content')
<div class="bg-cream rounded-2xl p-6 text-center mb-6">
    <h2 class="font-bold text-maroon mb-2">Monitoring Jadwal</h2>
    <p class="text-4xl font-bold text-blue-800 mb-1">06:54</p>
    <p class="text-gray-500 text-sm">Selasa, 24 Oktober 2023</p>
</div>

<h2 class="font-bold text-lg mb-3">Jadwal Hari Ini</h2>
<div class="space-y-3 mb-6">
    @foreach($today as $t)
    <div class="bg-white rounded-2xl border-l-4 {{ $t['status'] === 'ongoing' ? 'border-l-maroon' : 'border-l-blue-500' }} border border-gray-100 p-4 shadow-sm">
        <div class="flex justify-between items-center mb-1">
            <span class="text-gray-500 text-sm">{{ $t['time'] }}</span>
            <span class="{{ $t['status'] === 'ongoing' ? 'bg-maroon text-white' : 'bg-cream text-maroon' }} text-xs font-semibold px-3 py-1 rounded-full">
                {{ $t['status'] === 'ongoing' ? 'Sedang Berlangsung' : 'Akan Datang' }}
            </span>
        </div>
        <h3 class="font-bold">{{ $t['subject'] }}</h3>
        <p class="text-gray-500 text-sm">{{ $t['class'] }} • {{ $t['room'] }}</p>
        <p class="text-gray-500 text-sm">👤 {{ $t['teacher'] }}</p>
    </div>
    @endforeach
</div>

<div class="flex justify-between items-center mb-3">
    <h2 class="font-bold text-lg">Status Ruangan</h2>
    <a href="{{ route('viewer.ruangan.index') }}" class="text-maroon text-xs font-bold">LIHAT SEMUA</a>
</div>
<div class="grid grid-cols-2 gap-4 mb-6">
    <div class="bg-white rounded-2xl border border-gray-100 p-4 text-center">
        <p class="text-2xl mb-1">🚪</p>
        <p class="text-2xl font-bold text-maroon">5</p>
        <p class="text-xs text-gray-400 font-semibold">TERSEDIA</p>
    </div>
    <div class="bg-cream rounded-2xl border border-gray-100 p-4 text-center">
        <p class="text-2xl mb-1">⊖</p>
        <p class="text-2xl font-bold">18</p>
        <p class="text-xs text-gray-400 font-semibold">TERPAKAI</p>
    </div>
</div>

<h2 class="font-bold text-lg mb-3">Guru Piket Hari Ini</h2>
<div class="bg-white rounded-2xl border border-gray-100 p-4 flex items-center gap-3">
    <div class="w-10 h-10 rounded-xl bg-gold flex items-center justify-center font-bold">AG</div>
    <div>
        <p class="font-bold">Ahmad Gunawan, S.Pd</p>
        <p class="text-gray-500 text-sm">Lobi Utama</p>
    </div>
</div>
@endsection