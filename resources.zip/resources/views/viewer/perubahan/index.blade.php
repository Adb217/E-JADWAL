@extends('layouts.viewer')
@section('title','Info Perubahan')
@section('content')
<h1 class="text-xl font-bold text-maroon mb-1">Info Perubahan</h1>
<p class="text-gray-500 text-sm mb-4">Update terkini mengenai jadwal mengajar dan ruang kelas.</p>

<div class="space-y-4">
    @foreach($changes as $c)
    <div class="bg-cream rounded-2xl border-l-4 {{ $c['border'] }} p-4">
        <div class="flex justify-between items-start mb-3">
            <h3 class="font-bold text-lg">{{ $c['icon'] }} {{ $c['title'] }}</h3>
            <span class="{{ $c['badge'] }} text-white text-xs font-semibold px-3 py-1 rounded-full whitespace-nowrap">{{ $c['status'] }}</span>
        </div>
        @if(!empty($c['from']))
        <div class="bg-white rounded-xl p-3 flex justify-between items-center mb-3 text-sm">
            <div><p class="text-gray-400 text-xs font-semibold">{{ $c['from_label'] }}</p><p class="font-bold">{{ $c['from'] }}</p></div>
            <span>→</span>
            <div class="text-right"><p class="text-gray-400 text-xs font-semibold">{{ $c['to_label'] }}</p><p class="font-bold text-maroon">{{ $c['to'] }}</p></div>
        </div>
        @endif
        <p class="text-sm text-gray-600">ℹ️ Alasan: {{ $c['reason'] }}</p>
    </div>
    @endforeach
</div>
@endsection