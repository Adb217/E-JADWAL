<aside x-show="drawer" x-cloak x-transition
    class="fixed top-0 left-0 h-full w-72 bg-[#FBDCDC] z-50 p-6 overflow-y-auto">
    <div class="flex justify-end">
        <button @click="drawer = false" class="text-xl">✕</button>
    </div>
    <div class="flex flex-col items-center mt-2 mb-6">
        <img src="https://ui-avatars.com/api/?name=Admin+Kosgoro" class="w-20 h-20 rounded-2xl mb-3">
        <h2 class="text-xl font-bold text-maroon">Admin Kosgoro</h2>
        <p class="text-gray-500 text-sm">Administrator System</p>
        <p class="text-gray-400 text-xs">v1.0.4</p>
    </div>
    <nav class="space-y-1">
        <a href="{{ route('admin.dashboard') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl {{ request()->routeIs('admin.dashboard') ? 'bg-gold font-semibold' : 'hover:bg-white/50' }}">📊 Dashboard</a>
        <a href="{{ route('admin.jadwal.index') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl {{ request()->routeIs('admin.jadwal.*') ? 'bg-gold font-semibold' : 'hover:bg-white/50' }}">📅 Jadwal</a>
        <a href="{{ route('admin.kelas.index') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl {{ request()->routeIs('admin.kelas.*') ? 'bg-gold font-semibold' : 'hover:bg-white/50' }}">🚪 Kelas</a>
        <a href="{{ route('admin.guru.index') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl {{ request()->routeIs('admin.guru.*') ? 'bg-gold font-semibold' : 'hover:bg-white/50' }}">👥 Guru</a>
        <a href="{{ route('admin.mapel.index') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl {{ request()->routeIs('admin.mapel.*') ? 'bg-gold font-semibold' : 'hover:bg-white/50' }}">📖 Mapel</a>
        <a href="{{ route('admin.ruangan.index') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl {{ request()->routeIs('admin.ruangan.*') ? 'bg-gold font-semibold' : 'hover:bg-white/50' }}">🚪⚙ Ruangan</a>
        <a href="{{ route('admin.guru-piket.index') }}" class="flex items-center gap-3 px-4 py-3 rounded-xl {{ request()->routeIs('admin.guru-piket.*') ? 'bg-gold font-semibold' : 'hover:bg-white/50' }}">🪪 Guru Piket</a>
        <form method="POST" action="{{ route('logout') }}" class="pt-4">
            @csrf
            <button class="flex items-center gap-3 px-4 py-3 text-maroon font-semibold">🚪→ Logout</button>
        </form>
    </nav>
</aside>