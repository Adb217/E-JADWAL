
<nav class="fixed bottom-0 left-0 right-0 bg-cream border-t border-gray-200 z-20">
    <div class="max-w-md mx-auto grid grid-cols-4 text-center text-xs">
        <a href="{{ route('admin.dashboard') }}" class="py-3 {{ request()->routeIs('admin.dashboard') ? 'text-maroon font-bold' : 'text-gray-500' }}">🏠<br>Home</a>
        <a href="{{ route('admin.jadwal.index') }}" class="py-3 {{ request()->routeIs('admin.jadwal.*') ? 'text-maroon font-bold' : 'text-gray-500' }}">📅<br>Jadwal</a>
        <a href="{{ route('admin.guru.index') }}" class="py-3 {{ request()->routeIs('admin.guru.*') ? 'text-maroon font-bold' : 'text-gray-500' }}">👥<br>Guru</a>
        <a href="{{ route('admin.ruangan.index') }}" class="py-3 {{ request()->routeIs('admin.ruangan.*') ? 'text-maroon font-bold' : 'text-gray-500' }}">🚪<br>Ruangan</a>
    </div>
</nav>