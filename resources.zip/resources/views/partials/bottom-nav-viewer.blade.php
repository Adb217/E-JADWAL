<nav class="fixed bottom-0 left-0 right-0 bg-cream border-t border-gray-200 z-20">
    <div class="max-w-md mx-auto grid grid-cols-4 text-center text-xs">
        <a href="{{ route('viewer.dashboard') }}" class="py-3 {{ request()->routeIs('viewer.dashboard') ? 'text-maroon font-bold' : 'text-gray-500' }}">🏠<br>Home</a>
        <a href="{{ route('viewer.jadwal.index') }}" class="py-3 {{ request()->routeIs('viewer.jadwal.*') ? 'text-maroon font-bold' : 'text-gray-500' }}">📅<br>Schedule</a>
        <a href="{{ route('viewer.ruangan.index') }}" class="py-3 {{ request()->routeIs('viewer.ruangan.*') ? 'text-maroon font-bold' : 'text-gray-500' }}">🚪<br>Rooms</a>
        <a href="{{ route('viewer.perubahan.index') }}" class="py-3 {{ request()->routeIs('viewer.perubahan.*') ? 'text-maroon font-bold' : 'text-gray-500' }}">🔔<br>Changes</a>
    </div>
</nav>