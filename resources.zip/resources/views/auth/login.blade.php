@extends('layouts.guest')
@section('title', 'Login Admin')
@section('content')
<div class="w-full max-w-sm bg-white rounded-2xl shadow-lg p-8" x-data="{ show: false }">
    <div class="flex justify-center mb-4">
        <div class="w-20 h-20 rounded-2xl bg-cream flex items-center justify-center text-3xl">🎓</div>
    </div>
    <h1 class="text-2xl font-bold text-maroon text-center">Login Admin Monitoring</h1>
    <p class="text-center text-gray-500 mb-6">SMK Kosgoro Kota Bogor</p>

    <form method="POST" action="{{ route('login.post') }}" class="space-y-4">
        @csrf
        <div>
            <label class="block text-sm font-semibold text-maroon mb-1">Username</label>
            <div class="relative">
                <span class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">👤</span>
                <input type="text" name="username" placeholder="Masukkan username"
                    class="w-full pl-10 pr-4 py-3 rounded-xl bg-cream border border-gray-200 focus:outline-none focus:ring-2 focus:ring-maroon">
            </div>
        </div>
        <div>
            <label class="block text-sm font-semibold text-maroon mb-1">Password</label>
            <div class="relative">
                <span class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">🔒</span>
                <input :type="show ? 'text' : 'password'" name="password" placeholder="Masukkan password"
                    class="w-full pl-10 pr-10 py-3 rounded-xl bg-cream border border-gray-200 focus:outline-none focus:ring-2 focus:ring-maroon">
                <button type="button" @click="show = !show" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">👁</button>
            </div>
        </div>
        <button type="submit" class="w-full bg-maroon hover:bg-maroon-dark text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2">
            Masuk ke Sistem →
        </button>
    </form>

    <div class="text-center mt-4">
        <a href="{{ route('viewer.dashboard') }}" class="text-maroon font-semibold text-sm">← Kembali ke Beranda</a>
    </div>
    <hr class="my-4">
    <p class="text-center text-xs text-gray-400">Sistem Monitoring Jadwal v1.0.4</p>
</div>
@endsection