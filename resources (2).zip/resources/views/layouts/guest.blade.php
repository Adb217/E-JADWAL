<!DOCTYPE html>
<html lang="id">
<head>
<title>@yield('title', 'SMK Kosgoro')</title>
@include('partials.head')
</head>
<body class="bg-cream min-h-screen text-gray-800">
@yield('content')
</body>
</html>