<!DOCTYPE html>
<html lang="id">
<head>
<title>@yield('title', 'SMK Kosgoro - Monitoring')</title>
@include('partials.head')
</head>
<body class="bg-gray-50 min-h-screen text-gray-800 pb-20 lg:pb-0">

@php
$nav = [
    ['viewer.dashboard',       'viewer.dashboard',   'fa-house',         'Home'],
    ['viewer.jadwal.index',    'viewer.jadwal.*',    'fa-calendar-days', 'Schedule'],
    ['viewer.ruangan.index',   'viewer.ruangan.*',   'fa-door-open',     'Rooms'],
    ['viewer.perubahan.index', 'viewer.perubahan.*', 'fa-bell',          'Changes'],
];
@endphp

<header class="sticky top-0 z-30 bg-cream/95 backdrop-blur border-b border-gray-200">
    <div class="flex items-center justify-between h-14 lg:h-16 px-4 lg:px-8 max-w-6xl mx-auto">
        <div class="flex items-center gap-2">
            <span class="w-9 h-9 rounded-xl bg-maroon text-white flex items-center justify-center">
                <i class="fa-solid fa-graduation-cap"></i>
            </span>
            <h1 class="text-lg font-bold text-maroon">SMK Kosgoro</h1>
        </div>

        <nav class="hidden lg:flex items-center gap-1">
            @foreach($nav as [$route, $pattern, $icon, $label])
            <a href="{{ route($route) }}"
               class="flex items-center gap-2 px-4 py-2 rounded-full text-sm {{ request()->routeIs($pattern) ? 'bg-maroon text-white font-semibold' : 'text-gray-600 hover:bg-maroon/10' }}">
                <i class="fa-solid {{ $icon }}"></i>{{ $label }}
            </a>
            @endforeach
        </nav>

        <a href="{{ route('login') }}" class="flex items-center gap-2 text-maroon">
            <i class="fa-solid fa-user-lock text-lg"></i>
            <span class="hidden sm:inline text-sm font-semibold">Login Admin</span>
        </a>
    </div>
</header>

<main class="max-w-6xl mx-auto p-4 lg:p-8">
@yield('content')
</main>

@include('partials.bottom-nav-viewer')
</body>
</html>