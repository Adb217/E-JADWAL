<!DOCTYPE html>
<html lang="id">
<head>
<title>@yield('title', 'Admin - SMK Kosgoro')</title>
@include('partials.head')
</head>
<body class="bg-gray-50 min-h-screen text-gray-800" x-data="{ drawer: false }">

@include('partials.sidebar')

<div class="lg:pl-64 min-h-screen flex flex-col">
    <header class="sticky top-0 z-30 bg-cream/95 backdrop-blur border-b border-gray-200">
        <div class="flex items-center justify-between h-14 px-4 lg:px-8">
            <div class="flex items-center gap-3">
                <button @click="drawer = true" class="lg:hidden w-9 h-9 rounded-lg text-maroon hover:bg-maroon/10" aria-label="Menu">
                    <i class="fa-solid fa-bars"></i>
                </button>
                <h1 class="font-bold text-maroon lg:hidden">SMK Kosgoro</h1>
                <p class="hidden lg:block font-semibold text-gray-700">@yield('title')</p>
            </div>
            <div class="flex items-center gap-3">
                <span class="hidden sm:block text-sm text-gray-500">Admin Kosgoro</span>
                <span class="w-9 h-9 rounded-full bg-maroon text-white flex items-center justify-center">
                    <i class="fa-solid fa-user text-sm"></i>
                </span>
            </div>
        </div>
    </header>
<main class="flex-1 w-full max-w-7xl mx-auto p-4 lg:p-8 pb-24 lg:pb-8">
    @include('partials.flash')
    @yield('content')
</main>
<span class="hidden sm:block text-sm text-gray-500">{{ auth()->user()->name }}</span>
</div>

@include('partials.bottom-nav-admin')
</body>
</html>