@extends('layouts.viewer')
@section('title','Monitoring Jadwal')
@section('content')
<div x-data="{ t: new Date() }" x-init="setInterval(() => t = new Date(), 1000); setTimeout(() => location.reload(), 60000)"
     class="grid gap-6 lg:grid-cols-3 lg:items-start">

    <div class="bg-cream rounded-2xl p-6 text-center lg:col-start-3 lg:row-start-1">
        <h2 class="font-bold text-maroon mb-2">Monitoring Jadwal</h2>
        <p class="text-4xl lg:text-5xl font-bold text-maroon mb-1"
           x-text="t.toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).replace('.',':')">--:--</p>
        <p class="text-gray-500 text-sm"
           x-text="t.toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'})"></p>
    </div>

    <section class="lg:col-span-2 lg:col-start-1 lg:row-start-1 lg:row-span-3">
        <h2 class="font-bold text-lg mb-3">Jadwal Hari Ini</h2>
        <div class="grid gap-3 md:grid-cols-2">
            @forelse($today as $t)
            <div class="bg-white rounded-2xl border-l-4 {{ $t->border }} border border-gray-100 p-4 shadow-sm">
                <div class="flex justify-between items-center gap-2 mb-1">
                    <span class="text-gray-500 text-sm"><i class="fa-regular fa-clock mr-1"></i>{{ $t->mulai }} - {{ $t->selesai }}</span>
                    <span class="{{ $t->badge }} text-xs font-semibold px-3 py-1 rounded-full whitespace-nowrap">
                        {{ $t->status === 'Berlangsung' ? 'Sedang Berlangsung' : $t->status }}
                    </span>
                </div>
                <h3 class="font-bold">{{ $t->mapel->nama }}</h3>
                <p class="text-gray-500 text-sm">{{ $t->kelas->nama }} • {{ $t->ruangan->nama }}</p>
                <p class="text-gray-500 text-sm"><i class="fa-solid fa-user w-4 text-center mr-1"></i>{{ $t->guru->nama }}</p>
            </div>
            @empty
            <x-empty-state icon="fa-calendar-xmark" text="Tidak ada jadwal tersisa hari ini." />
            @endforelse
        </div>
    </section>

    <section class="lg:col-start-3 lg:row-start-2">
        <div class="flex justify-between items-center mb-3">
            <h2 class="font-bold text-lg">Status Ruangan</h2>
            <a href="{{ route('viewer.ruangan.index') }}" class="text-maroon text-xs font-bold">LIHAT SEMUA</a>
        </div>
        <div class="grid grid-cols-2 gap-4">
            <div class="bg-white rounded-2xl border border-gray-100 p-4 text-center">
                <i class="fa-solid fa-door-open text-xl text-green-600 mb-1"></i>
                <p class="text-2xl font-bold text-maroon">{{ $tersedia }}</p>
                <p class="text-xs text-gray-400 font-semibold">TERSEDIA</p>
            </div>
            <div class="bg-cream rounded-2xl border border-gray-100 p-4 text-center">
                <i class="fa-solid fa-door-closed text-xl text-maroon mb-1"></i>
                <p class="text-2xl font-bold">{{ $terpakai }}</p>
                <p class="text-xs text-gray-400 font-semibold">TERPAKAI</p>
            </div>
        </div>
    </section>

    <section class="lg:col-start-3 lg:row-start-3">
        <h2 class="font-bold text-lg mb-3">Guru Piket Hari Ini</h2>
        <div class="space-y-3">
            @forelse($piket as $p)
            <div class="bg-white rounded-2xl border border-gray-100 p-4 flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-gold flex items-center justify-center font-bold">{{ $p->guru->inisial }}</div>
                <div>
                    <p class="font-bold">{{ $p->guru->nama }}</p>
                    <p class="text-gray-500 text-sm"><i class="fa-solid fa-location-dot mr-1"></i>{{ $p->lokasi ?? '-' }}</p>
                </div>
            </div>
            @empty
            <p class="text-sm text-gray-400">Belum ada guru piket hari ini.</p>
            @endforelse
        </div>
    </section>
</div>
@endsection