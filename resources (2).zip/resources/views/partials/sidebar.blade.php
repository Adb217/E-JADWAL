@php
$menu = [
    ['admin.dashboard',        'admin.dashboard',        'fa-chart-pie',       'Dashboard'],
    ['admin.jadwal.index',     'admin.jadwal.*',         'fa-calendar-days',   'Jadwal'],
    ['admin.kelas.index',      'admin.kelas.*',          'fa-school',          'Kelas'],
    ['admin.guru.index',       'admin.guru.*',           'fa-chalkboard-user', 'Guru'],
    ['admin.mapel.index',      'admin.mapel.*',          'fa-book-open',       'Mapel'],
    ['admin.ruangan.index',    'admin.ruangan.*',        'fa-door-open',       'Ruangan'],
    ['admin.guru-piket.index', 'admin.guru-piket.*',     'fa-id-card',         'Guru Piket'],
    ['admin.perubahan.index', 'admin.perubahan.*', 'fa-bell', 'Perubahan'],
];
@endphp

<div x-show="drawer" x-cloak x-transition.opacity
     class="fixed inset-0 bg-black/40 z-40 lg:hidden" @click="drawer = false"></div>
<h2 class="text-lg font-bold text-maroon">{{ auth()->user()->name }}</h2>
<aside class="fixed inset-y-0 left-0 z-50 w-72 lg:w-64 bg-[#FBDCDC] flex flex-col p-5 overflow-y-auto
              -translate-x-full lg:translate-x-0 transition-transform duration-200"
       :class="drawer && '!translate-x-0'">

    <div class="flex justify-end lg:hidden">
        <button @click="drawer = false" class="w-9 h-9 rounded-lg hover:bg-white/50" aria-label="Tutup">
            <i class="fa-solid fa-xmark text-lg"></i>
        </button>
    </div>

    <div class="flex flex-col items-center mt-2 mb-6 text-center">
        <div class="w-16 h-16 rounded-2xl bg-maroon text-white flex items-center justify-center text-2xl mb-3">
            <i class="fa-solid fa-user-shield"></i>
        </div>
        <h2 class="text-lg font-bold text-maroon">Admin Kosgoro</h2>
        <p class="text-gray-500 text-sm">Administrator System</p>
        <p class="text-gray-400 text-xs">v1.0.4</p>
    </div>

    <nav class="space-y-1 flex-1">
        @foreach($menu as [$route, $pattern, $icon, $label])
        <a href="{{ route($route) }}"
           class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm {{ request()->routeIs($pattern) ? 'bg-gold font-semibold' : 'hover:bg-white/50' }}">
            <i class="fa-solid {{ $icon }} w-5 text-center"></i>{{ $label }}
        </a>
        @endforeach
    </nav>

    <form method="POST" action="{{ route('logout') }}" class="pt-4 mt-4 border-t border-maroon/20">
        @csrf
        <button class="flex items-center gap-3 px-4 py-2.5 text-maroon font-semibold text-sm w-full rounded-xl hover:bg-white/50">
            <i class="fa-solid fa-right-from-bracket w-5 text-center"></i>Logout
        </button>
    </form>
</aside>