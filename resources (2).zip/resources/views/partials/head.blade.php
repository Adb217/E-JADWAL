<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<script>
  tailwind.config = { theme: { extend: { colors: {
    maroon: { DEFAULT: '#7A0C1E', dark: '#5C0916' },
    gold: '#F2C200',
    cream: '#FDF1F1',
  }}}}
  <style type="text/tailwindcss">
  @layer components {
    .inp { @apply w-full border border-gray-200 rounded-xl p-3 mt-1 bg-white focus:outline-none focus:ring-2 focus:ring-maroon/40; }
    .lbl { @apply text-sm font-semibold text-maroon; }
    .btn { @apply inline-flex items-center justify-center gap-2 bg-maroon hover:bg-maroon-dark text-white font-semibold px-5 py-3 rounded-xl; }
    .btn-ghost { @apply inline-flex items-center justify-center gap-2 border border-gray-200 bg-white hover:bg-gray-50 text-maroon font-semibold px-5 py-3 rounded-xl; }
  }
</style>
</script>
<style>[x-cloak]{display:none !important}</style>