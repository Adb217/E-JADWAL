@if(session('success'))
<div class="mb-4 flex items-start gap-3 rounded-xl bg-green-50 border border-green-200 text-green-700 px-4 py-3 text-sm">
    <i class="fa-solid fa-circle-check mt-0.5"></i><span>{{ session('success') }}</span>
</div>
@endif
@if($errors->any())
<div class="mb-4 rounded-xl bg-red-50 border border-red-200 text-red-600 px-4 py-3 text-sm">
    <p class="font-semibold mb-1"><i class="fa-solid fa-circle-exclamation mr-1"></i>Periksa kembali isian kamu:</p>
    <ul class="list-disc pl-5">@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul>
</div>
@endif