@php
$items = [
    ['admin.dashboard',    'admin.dashboard', 'fa-house',           'Home'],
    ['admin.jadwal.index', 'admin.jadwal.*',  'fa-calendar-days',   'Jadwal'],
    ['admin.guru.index',   'admin.guru.*',    'fa-chalkboard-user', 'Guru'],
    ['admin.ruangan.index','admin.ruangan.*', 'fa-door-open',       'Ruangan'],
];
@endphp
<nav class="fixed bottom-0 inset-x-0 z-20 bg-cream border-t border-gray-200 lg:hidden">
    <div class="grid grid-cols-4 text-center text-xs">
        @foreach($items as [$route, $pattern, $icon, $label])
        <a href="{{ route($route) }}"
           class="flex flex-col items-center gap-1 py-2.5 {{ request()->routeIs($pattern) ? 'text-maroon font-bold' : 'text-gray-500' }}">
            <i class="fa-solid {{ $icon }} text-lg"></i>{{ $label }}
        </a>
        @endforeach
    </div>
</nav>