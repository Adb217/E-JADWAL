@extends('layouts.admin')
@section('title','Admin Dashboard')
@section('content')
<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    @foreach($stats as [$icon, $label, $value, $tone])
    <div class="bg-white rounded-2xl p-4 lg:p-5 shadow-sm border border-gray-100 flex flex-col lg:flex-row lg:items-center gap-3">
        <div class="w-11 h-11 rounded-xl {{ $tone }} flex items-center justify-center shrink-0"><i class="fa-solid {{ $icon }}"></i></div>
        <div>
            <p class="text-sm text-gray-500">{{ $label }}</p>
            <p class="text-2xl font-bold">{{ $value }}</p>
        </div>
    </div>
    @endforeach
</div>

<div class="grid lg:grid-cols-5 gap-6 items-start">
    <div class="lg:col-span-3 bg-white rounded-2xl border border-gray-100 shadow-sm">
        <div class="flex items-center justify-between p-4 border-b">
            <h2 class="font-bold text-lg">Jadwal Hari Ini</h2>
            <a href="{{ route('admin.jadwal.index') }}" class="text-maroon text-sm font-semibold">
                Lihat Semua <i class="fa-solid fa-arrow-right text-xs ml-1"></i>
            </a>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="text-gray-400 text-xs">
                    <tr><th class="text-left p-3">Waktu</th><th class="text-left p-3">Kelas</th><th class="text-left p-3">Mata Pelajaran</th></tr>
                </thead>
                <tbody>
                    @forelse($today as $j)
                    <tr class="border-t">
                        <td class="p-3 font-bold whitespace-nowrap">{{ $j->mulai }} - {{ $j->selesai }}</td>
                        <td class="p-3 whitespace-nowrap">{{ $j->kelas->nama }}</td>
                        <td class="p-3 font-semibold">{{ $j->mapel->nama }}</td>
                    </tr>
                    @empty
                    <tr><td colspan="3" class="p-6 text-center text-gray-400">Tidak ada jadwal hari ini.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <div class="lg:col-span-2 bg-cream rounded-2xl p-4 lg:p-5">
        <div class="flex items-center justify-between mb-4">
            <h2 class="font-bold text-lg">Perubahan Terkini</h2>
            <a href="{{ route('admin.perubahan.index') }}" class="text-maroon text-sm font-semibold">Kelola</a>
        </div>
        @forelse($perubahan as $p)
            @if($loop->first)<ol class="relative border-l-2 border-maroon/30 ml-1.5 space-y-3">@endif
            <li class="relative pl-5">
                <span class="absolute -left-[7px] top-4 w-3 h-3 rounded-full ring-4 ring-cream {{ $p->dot }}"></span>
                <div class="bg-white rounded-xl p-3 border border-gray-100">
                    <div class="flex justify-between gap-2 text-sm">
                        <span class="font-bold">{{ $p->judul }}</span>
                        <span class="text-gray-400 text-xs whitespace-nowrap">{{ $p->created_at->diffForHumans() }}</span>
                    </div>
                    <p class="text-sm text-gray-600 mt-1">{{ $p->dari ? $p->dari.' → '.$p->ke.'. ' : '' }}{{ $p->alasan }}</p>
                </div>
            </li>
            @if($loop->last)</ol>@endif
        @empty
            <p class="text-sm text-gray-400 text-center py-6">Belum ada perubahan.</p>
        @endforelse
    </div>
</div>
@endsection