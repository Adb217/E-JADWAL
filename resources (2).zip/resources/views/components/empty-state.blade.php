@props(['icon' => 'fa-inbox', 'text' => 'Belum ada data.'])
<div class="col-span-full bg-white rounded-2xl border border-dashed border-gray-300 p-10 text-center text-gray-400">
    <i class="fa-solid {{ $icon }} text-3xl mb-3 block"></i>{{ $text }}
</div>