@props(['title', 'store', 'update'])
<div x-show="open" x-cloak x-transition.opacity @keydown.escape.window="open = false"
     class="fixed inset-0 z-[60] flex items-end sm:items-center justify-center sm:p-4">
    <div class="absolute inset-0 bg-black/40" @click="open = false"></div>
    <form method="POST" :action="editing ? '{{ $update }}'.replace('_id_', editing) : '{{ $store }}'"
          class="relative bg-white w-full sm:max-w-lg rounded-t-2xl sm:rounded-2xl p-5 max-h-[90vh] overflow-y-auto space-y-4">
        @csrf
        <template x-if="editing"><input type="hidden" name="_method" value="PUT"></template>
        <div class="flex items-center justify-between">
            <h2 class="font-bold text-lg" x-text="(editing ? 'Edit ' : 'Tambah ') + '{{ $title }}'"></h2>
            <button type="button" @click="open = false" class="w-8 h-8 rounded-lg hover:bg-gray-100" aria-label="Tutup">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        {{ $slot }}
        <div class="flex justify-end gap-3 pt-2">
            <button type="button" @click="open = false" class="btn-ghost">Batal</button>
            <button class="btn"><i class="fa-solid fa-floppy-disk"></i>Simpan</button>
        </div>
    </form>
</div>