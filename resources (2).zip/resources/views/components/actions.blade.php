@props(['item', 'destroy', 'msg' => 'Hapus data ini?'])
<div class="flex justify-end gap-1">
    <button type="button" @click="edit(@js($item))" class="w-8 h-8 rounded-lg text-blue-600 hover:bg-blue-50" aria-label="Edit">
        <i class="fa-solid fa-pen-to-square"></i>
    </button>
    <form method="POST" action="{{ $destroy }}" onsubmit="return confirm(@js($msg))">
        @csrf @method('DELETE')
        <button class="w-8 h-8 rounded-lg text-red-600 hover:bg-red-50" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
    </form>
</div>