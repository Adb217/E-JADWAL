@props(['title', 'sub', 'add' => null, 'search' => null])
<div class="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4 mb-6">
    <div>
        <h1 class="text-xl lg:text-2xl font-bold">{{ $title }}</h1>
        <p class="text-gray-500 text-sm">{{ $sub }}</p>
    </div>
    <div class="flex flex-col sm:flex-row gap-3">
        @if($search)
        <form method="GET" class="relative flex-1 sm:w-72">
            <i class="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
            <input name="q" value="{{ request('q') }}" placeholder="{{ $search }}"
                class="w-full pl-11 pr-4 py-3 rounded-xl bg-cream border border-gray-200 focus:outline-none focus:ring-2 focus:ring-maroon/40">
        </form>
        @endif
        @if($add)
        <button type="button" @click="add()" class="btn"><i class="fa-solid fa-plus"></i>{{ $add }}</button>
        @endif
    </div>
</div>