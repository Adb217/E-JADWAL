@extends('layouts.guest')
@section('title', 'Login Admin')
@section('content')
<div class="min-h-screen lg:grid lg:grid-cols-2" x-data="{ show: false }">

    <div class="hidden lg:flex flex-col items-center justify-center bg-maroon text-white p-12 text-center">
        <div class="w-24 h-24 rounded-3xl bg-white/15 flex items-center justify-center text-4xl mb-6">
            <i class="fa-solid fa-graduation-cap"></i>
        </div>
        <h2 class="text-3xl font-bold mb-2">SMK Kosgoro Kota Bogor</h2>
        <p class="text-white/70 max-w-sm">Sistem monitoring jadwal pelajaran, ruangan, dan pengajar.</p>
    </div>

    <div class="min-h-screen flex items-center justify-center p-4 bg-gradient-to-b from-cream to-white">
        <div class="w-full max-w-sm bg-white rounded-2xl shadow-lg lg:shadow-none p-8">
            <div class="flex justify-center mb-4 lg:hidden">
                <div class="w-20 h-20 rounded-2xl bg-cream text-maroon flex items-center justify-center text-3xl">
                    <i class="fa-solid fa-graduation-cap"></i>
                </div>
            </div>
            <h1 class="text-2xl font-bold text-maroon text-center">Login Admin Monitoring</h1>
            <p class="text-center text-gray-500 mb-6">SMK Kosgoro Kota Bogor</p>

            <form method="POST" action="{{ route('login.post') }}" class="space-y-4">
                @csrf
                @if($errors->any())
<div class="rounded-xl bg-red-50 border border-red-200 text-red-600 text-sm px-4 py-3">
    <i class="fa-solid fa-circle-exclamation mr-1"></i>{{ $errors->first() }}
</div>
@endif
                <div>
                    <label class="block text-sm font-semibold text-maroon mb-1">Username</label>
                    <div class="relative">
                        <i class="fa-solid fa-user absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                        <input type="text" name="username" value="{{ old('username') }}" autofocus placeholder="Masukkan username"
    class="w-full pl-11 pr-4 py-3 rounded-xl bg-cream border border-gray-200 focus:outline-none focus:ring-2 focus:ring-maroon">
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-maroon mb-1">Password</label>
                    <div class="relative">
                        <i class="fa-solid fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                        <input :type="show ? 'text' : 'password'" name="password" placeholder="Masukkan password"
                            class="w-full pl-11 pr-11 py-3 rounded-xl bg-cream border border-gray-200 focus:outline-none focus:ring-2 focus:ring-maroon">
                        <button type="button" @click="show = !show" class="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">
                            <i class="fa-solid" :class="show ? 'fa-eye-slash' : 'fa-eye'"></i>
                        </button>
                    </div>
                </div>
                <button type="submit" class="w-full bg-maroon hover:bg-maroon-dark text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2">
                    Masuk ke Sistem <i class="fa-solid fa-arrow-right"></i>
                </button>
            </form>

            <div class="text-center mt-4">
                <a href="{{ route('viewer.dashboard') }}" class="text-maroon font-semibold text-sm">
                    <i class="fa-solid fa-arrow-left mr-1"></i>Kembali ke Beranda
                </a>
            </div>
            <hr class="my-4">
            <p class="text-center text-xs text-gray-400">Sistem Monitoring Jadwal v1.0.4</p>
        </div>
    </div>
</div>
@endsection